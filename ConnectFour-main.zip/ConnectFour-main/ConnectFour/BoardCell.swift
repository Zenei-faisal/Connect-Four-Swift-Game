

import UIKit

class BoardCell: UICollectionViewCell
{
	@IBOutlet weak var image: UIImageView!
}
